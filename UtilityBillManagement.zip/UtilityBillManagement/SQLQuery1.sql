CREATE DATABASE BuildingDB 
GO 

Use BuildingDB
go 

---relational data combo box for master table
Create table Flat (
FlatID int primary key not null,
FlatNo nvarchar (50) not null,
FlatType nvarchar(50) not null)
go 

Create table BillType (
BillTypeID int primary key not null,
BillType nvarchar(50) not null)
go 

insert into BillType values (1, 'Water'),
(2, 'Gas'), (3, 'Electricity'),(4, 'internet'), (5, 'Other')
Go 

select * from BillType 
go 

select * from Flat 
go 

---master table 
create table Tenant (
TenantID int primary key not null,
TenantName nvarchar(50) not null,
FlatID int references Flat(FlatID),
PaymentDate date not null,
TenantStatus nvarchar (20) not null,
Picture varbinary(max) not null
)
go 

select * from Tenant

---- details table 
create table BillPayment (
BillPaidID int primary key identity(1,1) not null,
BillTypeID int references BillType(BillTypeID),
BillAmount money not null,
TenantID int references Tenant(TenantID)
) 
go 

select * from BillPayment
