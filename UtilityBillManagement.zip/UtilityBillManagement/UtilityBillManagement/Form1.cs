﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UtilityBillManagement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void entryUpdateDeleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFlat flat = new frmFlat();
            flat.StartPosition = FormStartPosition.CenterScreen;
            flat.Show();
        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMasterDetails md = new frmMasterDetails();
            md.StartPosition = FormStartPosition.CenterScreen;
            md.Show();
        }

        private void allTenantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAllTenantsReport report = new frmAllTenantsReport();
            report.Show();
            report.MdiParent = this;
        }
    }
}
