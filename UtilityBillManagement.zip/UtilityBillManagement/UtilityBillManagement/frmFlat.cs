﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UtilityBillManagement
{
    public partial class frmFlat : Form
    {
        SqlConnection con = new SqlConnection(@"Server=.;Database=BuildingDB;Trusted_Connection=True");
        public frmFlat()
        {
            InitializeComponent();
        }

        private void frmFlat_Load(object sender, EventArgs e)
        {
            LoadGrid();
        }

        private void LoadGrid()
        {
            SqlDataAdapter sqlda = new SqlDataAdapter("select * from Flat", con);
            DataTable dt = new DataTable();
            sqlda.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into Flat (FlatID, FlatNo, FlatType) values (@id, @no, @type)", con);
                cmd.Parameters.AddWithValue("@id", txtId.Text);
                cmd.Parameters.AddWithValue("@no", txtFlatno.Text);
                cmd.Parameters.AddWithValue("@type", txtFlatType.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("New Flat Added!!", "Insert Message");
                LoadGrid();
                txtId.Text = "";
                txtFlatno.Text = "";
                txtFlatType.Text = "";

            }
            catch (Exception ex)
            {
                MessageBox.Show("Insert Valid Data\n" + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update Flat set FlatNo=@no, FlatType=@type where FlatID=@id", con);
                cmd.Parameters.AddWithValue("@id", txtId.Text);
                cmd.Parameters.AddWithValue("@no", txtFlatno.Text);
                cmd.Parameters.AddWithValue("@type", txtFlatType.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Flat Details Updated!!", "Update Message");
                LoadGrid();
                txtId.Text = "";
                txtFlatno.Text = "";
                txtFlatType.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insert Valid Data\n" + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtId.Clear();
            txtFlatno.Clear();
            txtFlatType.Clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return; 
            try
            {
                int id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value);
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select FlatID, FlatNo, FlatType from Flat where FlatID =" + id + " ", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    txtId.Text = dt.Rows[0][0].ToString();
                    txtFlatno.Text = dt.Rows[0][1].ToString();
                    txtFlatType.Text = dt.Rows[0][2].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
