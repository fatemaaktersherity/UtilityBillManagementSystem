﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UtilityBillManagement
{
    public partial class frmMasterDetails : Form
    {
        SqlConnection con = new SqlConnection(@"Server=.;Database=BuildingDB;Trusted_Connection=True");
        DataTable dtBillDetails;

        public frmMasterDetails()
        {
            InitializeComponent();
        }

        private void frmMasterDetails_Load(object sender, EventArgs e)
        {
            LoadData();
            LoadFlatCombo();

            dtBillDetails = new DataTable();
            dtBillDetails.Columns.Add("BillTypeID", typeof(int));
            dtBillDetails.Columns.Add("BillAmount", typeof(decimal));
            dgvDetails.DataSource = dtBillDetails;
        }

        private void LoadFlatCombo()
        {
            
            SqlDataAdapter da = new SqlDataAdapter("Select * from Flat", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DataRow newRow = ds.Tables[0].NewRow();
            newRow[0] = "-1";
            newRow[1] = "---Select a Flat----";
            ds.Tables[0].Rows.InsertAt(newRow, 0);
            cmbFlat.DataSource = ds.Tables[0];
            cmbFlat.ValueMember = "FlatID";
            cmbFlat.DisplayMember = "FlatNo";

        }

        private void LoadData()
        {
            
            SqlDataAdapter da = new SqlDataAdapter(@"select t.TenantID, t.TenantName, t.FlatID, t.PaymentDate, t.TenantStatus, t.Picture from Tenant t join Flat f on t.FlatID = f.FlatID", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgvMasterDetails.DataSource = dt;
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                Image img = Image.FromFile(txtPicture.Text);
                MemoryStream ms = new MemoryStream();
                img.Save(ms, ImageFormat.Bmp);
                con.Open();

                SqlCommand cmd = new SqlCommand("insert into Tenant (TenantID, TenantName, FlatID, PaymentDate, TenantStatus, Picture) values(@tid, @tn, @fid, @date, @s, @p)", con);
                cmd.Parameters.AddWithValue("@tid", txtId.Text);
                cmd.Parameters.AddWithValue("@tn", txtTname.Text);
                cmd.Parameters.AddWithValue("@fid", cmbFlat.SelectedValue ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@date", dateTimePicker1.Value);
                cmd.Parameters.AddWithValue("@s", isActive.Checked ? "Active" : "Not Active");
                cmd.Parameters.Add(new SqlParameter("@p", SqlDbType.VarBinary) { Value = ms.ToArray() });
                cmd.ExecuteNonQuery();

                foreach (DataRow row in dtBillDetails.Rows)
                {
                    if (row["BillTypeID"] == DBNull.Value || row["BillAmount"] == DBNull.Value) continue;

                    SqlCommand sqlcmd = new SqlCommand(@"insert into BillPayment(BillTypeID, BillAmount, TenantID) values (@bid, @ba, @tit)", con);
                    sqlcmd.Parameters.AddWithValue("@bid", Convert.ToInt32(row["BillTypeID"]));
                    sqlcmd.Parameters.AddWithValue("@ba", Convert.ToDecimal(row["BillAmount"]));
                    sqlcmd.Parameters.AddWithValue("@tit", Convert.ToInt32(txtId.Text));
                    sqlcmd.ExecuteNonQuery();
                }

                LoadData();
                MessageBox.Show("Insert saved successfully", "Insert Message");
                ClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Invalid Input\n" + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvMasterDetails.CurrentRow == null) return;

            try
            {
                int tenantId = Convert.ToInt32(txtId.Text);
                con.Open();

                byte[] pictureBytes;

                if (!string.IsNullOrWhiteSpace(txtPicture.Text))
                {
                    using (Image img = Image.FromFile(txtPicture.Text))
                    using (MemoryStream ms = new MemoryStream())
                    {
                        img.Save(ms, ImageFormat.Bmp);
                        pictureBytes = ms.ToArray();
                    }
                }
                else
                {
                    pictureBytes = (byte[])dgvMasterDetails.CurrentRow.Cells["Picture"].Value;
                }

                SqlCommand cmd = new SqlCommand(@"update Tenant set TenantName=@tn, FlatID=@fid, PaymentDate=@date, TenantStatus=@s, Picture=@p where TenantID=@tid", con);
                cmd.Parameters.AddWithValue("@tid", tenantId);
                cmd.Parameters.AddWithValue("@tn", txtTname.Text);
                cmd.Parameters.AddWithValue("@fid", cmbFlat.SelectedValue ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@date", dateTimePicker1.Value);
                cmd.Parameters.AddWithValue("@s", isActive.Checked ? "Active" : "Not Active");
                cmd.Parameters.Add(new SqlParameter("@p", SqlDbType.VarBinary) { Value = pictureBytes });
                cmd.ExecuteNonQuery();

                if (dtBillDetails.Rows.Count > 0)
                {
                    SqlCommand delDetail = new SqlCommand("delete from BillPayment where TenantID = @id", con);
                    delDetail.Parameters.AddWithValue("@id", tenantId);
                    delDetail.ExecuteNonQuery();

                    foreach (DataRow row in dtBillDetails.Rows)
                    {
                        if (row["BillTypeID"] == DBNull.Value || row["BillAmount"] == DBNull.Value) continue;

                        SqlCommand sqlcmd = new SqlCommand(@"insert into BillPayment(BillTypeID, BillAmount, TenantID) values (@bid, @ba, @tid)", con);
                        sqlcmd.Parameters.AddWithValue("@bid", Convert.ToInt32(row["BillTypeID"]));
                        sqlcmd.Parameters.AddWithValue("@ba", Convert.ToDecimal(row["BillAmount"]));
                        sqlcmd.Parameters.AddWithValue("@tid", tenantId);
                        sqlcmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Updated Successfully");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
                LoadData();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvMasterDetails.CurrentRow == null) return;

            int tenantId = Convert.ToInt32(txtId.Text);

            try
            {
                con.Open();

                SqlCommand cmdDetail = new SqlCommand("delete from BillPayment where TenantID = @id", con);
                cmdDetail.Parameters.AddWithValue("@id", tenantId);
                cmdDetail.ExecuteNonQuery();

                SqlCommand cmdMaster = new SqlCommand("delete from Tenant where TenantID = @id", con);
                cmdMaster.Parameters.AddWithValue("@id", tenantId);
                cmdMaster.ExecuteNonQuery();

                MessageBox.Show("Deleted Successfully", "Delete Message");
                ClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
                LoadData();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void ClearData()
        {
            txtId.Clear();
            txtTname.Clear();
            cmbFlat.SelectedIndex = 0;
            dateTimePicker1.Value = DateTime.Now;
            isActive.Checked = false;
            txtPicture.Clear();
            pictureBox1.Image = null;
            dtBillDetails.Rows.Clear();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Image img = Image.FromFile(openFileDialog1.FileName);
                this.pictureBox1.Image = img;
                txtPicture.Text = openFileDialog1.FileName;
            }
        }

        private void LoadBillPayments(int tenantId)
        {
            SqlDataAdapter da = new SqlDataAdapter(
                @"select bp.BillPaidID, bp.BillTypeID, bt.BillType, bp.BillAmount 
                  from BillPayment bp 
                  join BillType bt on bp.BillTypeID = bt.BillTypeID 
                  where bp.TenantID = @id", con);
            da.SelectCommand.Parameters.AddWithValue("@id", tenantId);
            DataTable dt = new DataTable();
            da.Fill(dt);


            dtBillDetails.Rows.Clear();
            foreach (DataRow row in dt.Rows)
                dtBillDetails.Rows.Add(row["BillTypeID"], row["BillAmount"]);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtId.Text.Trim();
            if (keyword == "")
            {
                LoadData();
                dtBillDetails.Rows.Clear();
                return;
            }

            con.Open();

            SqlDataAdapter daMaster = new SqlDataAdapter(
                @"select t.TenantID, t.TenantName, t.FlatID, t.PaymentDate, t.TenantStatus, t.Picture 
              from Tenant t join Flat f on t.FlatID = f.FlatID 
              where t.TenantID = @id", con);
            daMaster.SelectCommand.Parameters.AddWithValue("@id", Convert.ToInt32(keyword));
            DataTable dtMaster = new DataTable();
            daMaster.Fill(dtMaster);
            dgvMasterDetails.DataSource = dtMaster;

            LoadBillPayments(Convert.ToInt32(keyword));
            con.Close();
        }

        private void dgvMasterDetails_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            int tenantId = Convert.ToInt32(dgvMasterDetails.Rows[e.RowIndex].Cells[0].Value);

            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(
                "select * from Tenant where TenantID=" + tenantId + "", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            if (dt.Rows.Count == 0) return;

            txtId.Text = dt.Rows[0][0].ToString();
            txtTname.Text = dt.Rows[0][1].ToString();
            cmbFlat.SelectedValue = dt.Rows[0][2].ToString();

            if (dt.Rows[0][3] != DBNull.Value)
                dateTimePicker1.Value = Convert.ToDateTime(dt.Rows[0][3]);

            isActive.Checked = dt.Rows[0][4].ToString() == "Active";

            byte[] bytes = (byte[])dt.Rows[0][5];
            MemoryStream ms = new MemoryStream(bytes);
            pictureBox1.Image = Image.FromStream(ms);

            txtPicture.Clear();

            LoadBillPayments(tenantId);
        }
    }
}